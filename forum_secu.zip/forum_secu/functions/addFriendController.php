<?php
require_once 'utilisateurController.php';

addFriend();
