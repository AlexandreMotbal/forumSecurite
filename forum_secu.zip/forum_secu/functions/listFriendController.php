<?php
require_once 'utilisateurController.php';

listFriend();
