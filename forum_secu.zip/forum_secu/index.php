<?php
?>

<html>
    <head>
        <title>Forum Secu</title>
        <link rel="stylesheet" type="text/css" href="styles.css"/>
        <link rel="stylesheet" type="text/css" href="index.css"/>
    </head>
    <body>
        <div id="left">
            <h1 id ="welcome">WELCOME</h1>
            <h2 id="subtitle">The splendid Website</h2>
            <p id="subtext">
                Welcome to our plateform, this website can be 
                used has a storage and has a forum
            </p>
        </div>

        <div id ="right">
            <a href="log.php" id="btn_account">
                <img src="img/icon_account.png" width="20%" alt="ce connecter"/>
                Account
            </a>

            <a href="choose.php" id="next">
                <div id="left_text">
                    <div id="start">Get Started</div>
                    <img src="img/separator.png" width="80%"/>
                    <div id="sub">Chat|Gallery</div>
                    
                </div>
                <div id="row">
                    <img src="img/row.png" />
                </div>
            </a>
        </div>
    </body> 
</html>