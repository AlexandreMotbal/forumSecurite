<?php
session_start();

require_once 'functions/bdd.php';

$see_tchat = $_ENV['conn']->query("SELECT t.*, l.pseudo 
    FROM tchat t 
    LEFT JOIN login l ON l.id = t.id_pseudo 
    ORDER BY date_message 
    LIMIT 100");

$see_tchat = $see_tchat->fetchAll();

?>